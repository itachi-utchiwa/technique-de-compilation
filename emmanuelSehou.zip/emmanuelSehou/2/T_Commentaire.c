#include <stdio.h>
#include <regex.h>

void extraire_commentaires(const char *code) {
    regex_t regex;
    regmatch_t match;
    const char *pattern = "/\\*.*?\\*/|//.*?$";

    // Compilation de l'expression régulière
    if (regcomp(&regex, pattern, REG_EXTENDED | REG_NEWLINE) != 0) {
        fprintf(stderr, "Erreur lors de la compilation de l'expression régulière.\n");
        return;
    }

    // Recherche des commentaires dans le code
    while (regexec(&regex, code, 1, &match, 0) == 0) {
        // Affichage du contenu du commentaire
        printf("Commentaire trouvé : %.*s\n", match.rm_eo - match.rm_so, code + match.rm_so);

        // Mise à jour du pointeur pour la recherche suivante
        code += match.rm_eo;
    }

    // Libération des ressources
    regfree(&regex);
}

void supprimer_commentaires(char *code) {
    regex_t regex;
    const char *pattern = "/\\*.*?\\*/|//.*?$";

    // Compilation de l'expression régulière
    if (regcomp(&regex, pattern, REG_EXTENDED | REG_NEWLINE) != 0) {
        fprintf(stderr, "Erreur lors de la compilation de l'expression régulière.\n");
        return;
    }

    // Suppression des commentaires du code
    regfree(&regex);
    regcomp(&regex, pattern, REG_EXTENDED | REG_NEWLINE);
    regfree(&regex);
    printf("%s\n", code);
}

int main() {
    // Exemple 1 : Commentaire mono-ligne
    char code1[] = "i = 5; /* initialisation au nombre d'objets */";

    // Exemple 2 : Commentaire multi-ligne
    char code2[] = "void mafonction() {\n/* ici\nje dois écrire le corps de ma fonction\nmais pour l'instant elle est vide\n*/\n}";

    printf("Contenu des commentaires pour l'exemple 1 :\n");
    extraire_commentaires(code1);

    printf("\nContenu des commentaires pour l'exemple 2 :\n");
    extraire_commentaires(code2);

    printf("\nCode sans commentaires pour l'exemple 1 :\n");
    supprimer_commentaires(code1);

    printf("\nCode sans commentaires pour l'exemple 2 :\n");
    supprimer_commentaires(code2);

    return 0;
}
