
#ifndef MAIN_C
#define MAIN_C

#include <stdio.h>

extern int yylex();

int main() {
    yylex();
    return 0;
}

#endif
