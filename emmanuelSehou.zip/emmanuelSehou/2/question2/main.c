#include <stdio.h>

extern int yylex();

int main() {
    yylex();
    return 0;
}
