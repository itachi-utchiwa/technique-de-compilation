# Projet d'Analyseur Lexical

## Compilation
Pour compiler le projet, exécutez la commande suivante dans le terminal:
	 flex lexer.flex
ensuite: gcc -o lexer lex.yy.c -lfl
et enfin: ./lexer
