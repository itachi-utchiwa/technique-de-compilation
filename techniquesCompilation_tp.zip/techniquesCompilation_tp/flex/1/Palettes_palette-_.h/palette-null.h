//TEST : head -7 palette-*.h
// BOLD UND  REV
// FG0  FG1  FG2  FG3  FG4  FG5  FG6  FG7
// FG8  FG9  FG10 FG11 FG12 FG13 FG14 FG15
// BG0  BG1  BG2  BG3  BG4  BG5  BG6  BG7
// BG8  BG9  BG10 BG11 BG12 BG13 BG14 BG15
#define NAME_PALETTE "NULL : No Attrinutes"
//
#define ATT_RST   ""
//
#define ATT_BOLD  ""
#define ATT_UND   ""
#define ATT_REV   ""
//
#define ATT_FG0  ""
#define ATT_FG1  ""
#define ATT_FG2  ""
#define ATT_FG3  ""
#define ATT_FG4  ""
#define ATT_FG5  ""
#define ATT_FG6  ""
#define ATT_FG7  "" 
#define ATT_FG8  ""
#define ATT_FG9  ""
#define ATT_FG10 ""
#define ATT_FG11 ""
#define ATT_FG12 ""
#define ATT_FG13 ""
#define ATT_FG14 ""
#define ATT_FG15 "" 
//
#define ATT_BG0  ""
#define ATT_BG1  ""
#define ATT_BG2  ""
#define ATT_BG3  ""
#define ATT_BG4  ""
#define ATT_BG5  ""
#define ATT_BG6  ""
#define ATT_BG7  "" 
#define ATT_BG8  ""
#define ATT_BG9  ""
#define ATT_BG10 ""
#define ATT_BG11 ""
#define ATT_BG12 ""
#define ATT_BG13 ""
#define ATT_BG14 ""
#define ATT_BG15 "" 
