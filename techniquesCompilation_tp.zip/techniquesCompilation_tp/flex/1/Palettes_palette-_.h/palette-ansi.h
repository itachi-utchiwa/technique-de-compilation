//TEST : head -7 palette-*.h
// [1mBOLD[0m [4mUND[0m  [7mREV[0m 
// [30mFG0[0m  [31mFG1[0m  [32mFG2[0m  [33mFG3[0m  [34mFG4[0m  [35mFG5[0m  [36mFG6[0m  [37mFG7[0m
// [90mFG8[0m  [91mFG9[0m  [92mFG10[0m [93mFG11[0m [94mFG12[0m [95mFG13[0m [96mFG14[0m [97mFG15[0m 
// [40mBG0[0m  [41mBG1[0m  [42mBG2[0m  [43mBG3[0m  [44mBG4[0m  [45mBG5[0m  [46mBG6[0m  [47mBG7[0m
// [100mBG8[0m  [101mBG9[0m  [102mBG10[0m [103mBG11[0m [104mBG12[0m [105mBG13[0m [106mBG14[0m [107mBG15[0m 
#define NAME_PALETTE "ANSI-VT100-Normal/High intensity"
//
#define ATT_RST   "\x1B[0m"
//
#define ATT_BOLD  "\x1B[1m"
#define ATT_UND   "\x1B[4m"
#define ATT_REV   "\x1B[7m"
//
#define ATT_FG0  "\x1B[30m"
#define ATT_FG1  "\x1B[31m"
#define ATT_FG2  "\x1B[32m"
#define ATT_FG3  "\x1B[33m"
#define ATT_FG4  "\x1B[34m"
#define ATT_FG5  "\x1B[35m"
#define ATT_FG6  "\x1B[36m"
#define ATT_FG7  "\x1B[37m" 
#define ATT_FG8  "\x1B[90m"
#define ATT_FG9  "\x1B[91m"
#define ATT_FG10 "\x1B[92m"
#define ATT_FG11 "\x1B[93m"
#define ATT_FG12 "\x1B[94m"
#define ATT_FG13 "\x1B[95m"
#define ATT_FG14 "\x1B[96m"
#define ATT_FG15 "\x1B[97m" 
//
#define ATT_BG0  "\x1B[40m"
#define ATT_BG1  "\x1B[41m"
#define ATT_BG2  "\x1B[42m"
#define ATT_BG3  "\x1B[43m"
#define ATT_BG4  "\x1B[44m"
#define ATT_BG5  "\x1B[45m"
#define ATT_BG6  "\x1B[46m"
#define ATT_BG7  "\x1B[47m" 
#define ATT_BG8  "\x1B[100m"
#define ATT_BG9  "\x1B[101m"
#define ATT_BG10 "\x1B[102m"
#define ATT_BG11 "\x1B[103m"
#define ATT_BG12 "\x1B[104m"
#define ATT_BG13 "\x1B[105m"
#define ATT_BG14 "\x1B[106m"
#define ATT_BG15 "\x1B[107m" 
// Color name 	Standard VGA 	Windows XP CMD 	Terminal.app 	PuTTY 		xterm 		CSS/HTML 	X
//NORMAL INTENSITY
//Black 	0, 0, 0 	0, 0, 0 	0, 0, 0 	0, 0, 0 	0, 0, 0 	0, 0, 0 	0, 0, 0
//Red 		170, 0, 0 	128, 0, 0 	194, 54, 33 	187, 0, 0 	205, 0, 0 	255, 0, 0 	255, 0, 0
//Green 	0, 170, 0 	0, 128, 0 	37, 188, 36 	0, 187, 0 	0, 205, 0 	0, 255, 0 	0, 128, 0
//yellow 	170, 85, 0 	128, 128, 0 	173, 173, 39 	187, 187, 0 	205, 205, 0 	255, 255, 0 	255, 255, 0
//Blue 		0, 0, 170 	0, 0, 128 	73, 46, 225 	0, 0, 187 	0, 0, 238 	0, 0, 255 	0, 0, 255
//Magenta 	170, 0, 170 	128, 0, 128 	211, 56, 211 	187, 0, 187 	205, 0, 205 	255, 0, 255 	255, 0, 255
//Cyan 		0, 170, 170 	0, 128, 128 	51, 187, 200 	0, 187, 187 	0, 205, 205 	0, 255, 255 	0, 255, 255
//Gray 		170, 170, 170 	192, 192, 192 	203, 204, 205 	187, 187, 187 	229, 229, 229 	255, 255, 255 	255, 255, 255
//HIGH INTENSITY
//Darkgray 	85, 85, 85 	128, 128, 128 	129, 131, 131 	85, 85, 85 	127, 127, 127 		
//Red 		255, 85, 85 	255, 0, 0 	252,57,31 	255, 85, 85 	255, 0, 0 		
//Green 	85, 255, 85 	0, 255, 0 	49, 231, 34 	85, 255, 85 	0, 255, 0 	144, 238, 144 	144, 238, 144
//Yellow 	255, 255, 85 	255, 255, 0 	234, 236, 35 	255, 255, 85 	255, 255, 0 	255, 255, 224 	225, 255, 224
//Blue 		85, 85, 255 	0, 0, 255 	88, 51, 255 	85, 85, 255 	92, 92, 255 	173, 216, 230 	173, 216, 230
//Magenta 	255, 85, 255 	255, 0, 255 	249, 53, 248 	255, 85, 255 	255, 0, 255 		
//Cyan 		85, 255, 255 	0, 255, 255 	20, 240, 240 	85, 255, 255 	0, 255, 255 	224, 255, 255 	224, 255, 255
//White 	255, 255, 255 	255, 255, 255 	233, 235, 235 	255, 255, 255 	255, 255, 255 		
