//TEST : head -7 palette-*.h
// [1mBOLD[0m [4mUND[0m  [7mREV[0m
// [38;2;181;137;0mFG0[0m  [38;2;203;75;22mFG1[0m  [38;2;220;50;47mFG2[0m  [38;2;211;54;130mFG3[0m  [38;2;108;113;196mFG4[0m  [38;2;38;139;210mFG5[0m  [38;2;42;161;152mFG6[0m  [38;2;133;153;0mFG7[0m
// [38;2;0;43;54mFG8[0m  [38;2;7;54;66mFG9[0m  [38;2;88;110;117mFG10[0m [38;2;101;123;131mFG11[0m [38;2;131;148;150mFG12[0m [38;2;147;161;161mFG13[0m [38;2;238;232;213mFG14[0m [38;2;253;246;227mFG15[0m
// [48;2;181;137;0mBG0[0m  [48;2;203;75;22mBG1[0m  [48;2;220;50;47mBG2[0m  [48;2;211;54;130mBG3[0m  [48;2;108;113;196mBG4[0m  [48;2;38;139;210mBG5[0m  [48;2;42;161;152mBG6[0m  [48;2;133;153;0mBG7[0m
// [48;2;0;43;54mBG8[0m  [48;2;7;54;66mBG9[0m  [48;2;88;110;117mBG10[0m [48;2;101;123;131mBG11[0m [48;2;131;148;150mBG12[0m [48;2;147;161;161mBG13[0m [48;2;238;232;213mBG14[0m [48;2;253;246;227mBG15[0m
#define NAME_PALETTE "SOLARIZED-XtermRGB" // require ISO-8613-3 24-bit color
//
#define ATT_RST   "\x1B[0m"
//
#define ATT_BOLD  "\x1B[1m"
#define ATT_UND   "\x1B[4m"
#define ATT_REV   "\x1B[7m"
//
// NB :  ok xterm sur ssh.int-evry.fr avec FG2 pas tres rouge!
#define ATT_FG0  "\x1B[38;2;181;137;0m"
#define ATT_FG1  "\x1B[38;2;203;75;22m"
#define ATT_FG2  "\x1B[38;2;220;50;47m"
#define ATT_FG3  "\x1B[38;2;211;54;130m"
#define ATT_FG4  "\x1B[38;2;108;113;196m"
#define ATT_FG5  "\x1B[38;2;38;139;210m"
#define ATT_FG6  "\x1B[38;2;42;161;152m"
#define ATT_FG7  "\x1B[38;2;133;153;0m" 
#define ATT_FG8  "\x1B[38;2;0;43;54m"
#define ATT_FG9  "\x1B[38;2;7;54;66m"
#define ATT_FG10 "\x1B[38;2;88;110;117m"
#define ATT_FG11 "\x1B[38;2;101;123;131m"
#define ATT_FG12 "\x1B[38;2;131;148;150m"
#define ATT_FG13 "\x1B[38;2;147;161;161m"
#define ATT_FG14 "\x1B[38;2;238;232;213m"
#define ATT_FG15 "\x1B[38;2;253;246;227m" 
//
#define ATT_BG0  "\x1B[48;2;181;137;0m"
#define ATT_BG1  "\x1B[48;2;203;75;22m"
#define ATT_BG2  "\x1B[48;2;220;50;47m"
#define ATT_BG3  "\x1B[48;2;211;54;130m"
#define ATT_BG4  "\x1B[48;2;108;113;196m"
#define ATT_BG5  "\x1B[48;2;38;139;210m"
#define ATT_BG6  "\x1B[48;2;42;161;152m"
#define ATT_BG7  "\x1B[48;2;133;153;0m" 
#define ATT_BG8  "\x1B[48;2;0;43;54m"
#define ATT_BG9  "\x1B[48;2;7;54;66m"
#define ATT_BG10 "\x1B[48;2;88;110;117m"
#define ATT_BG11 "\x1B[48;2;101;123;131m"
#define ATT_BG12 "\x1B[48;2;131;148;150m"
#define ATT_BG13 "\x1B[48;2;147;161;161m"
#define ATT_BG14 "\x1B[48;2;238;232;213m"
#define ATT_BG15 "\x1B[48;2;253;246;227m" 
//-----------------------------------------------------------
// SOLARIZED HEX     16/8 TERMCOL  XTERM/HEX    sRGB        
// base03    #002b36  8/4 brblack  234 #1c1c1c    0  43  54 
// base02    #073642  0/4 black    235 #262626    7  54  66 
// base01    #586e75 10/7 brgreen  240 #4e4e4e   88 110 117 
// base00    #657b83 11/7 bryellow 241 #585858  101 123 131 
// base0     #839496 12/6 brblue   244 #808080  131 148 150 
// base1     #93a1a1 14/4 brcyan   245 #8a8a8a  147 161 161 
// base2     #eee8d5  7/7 white    254 #d7d7af  238 232 213 
// base3     #fdf6e3 15/7 brwhite  230 #ffffd7  253 246 227 
// yellow    #b58900  3/3 yellow   136 #af8700  181 137   0 
// orange    #cb4b16  9/3 brred    166 #d75f00  203  75  22 
// red       #dc322f  1/1 red      160 #d70000  220  50  47 
// magenta   #d33682  5/5 magenta  125 #af005f  211  54 130 
// violet    #6c71c4 13/5 brmagenta 61 #5f5faf  108 113 196 
// blue      #268bd2  4/4 blue      33 #0087ff   38 139 210 
// cyan      #2aa198  6/6 cyan      37 #00afaf   42 161 152 
// green     #859900  2/2 green     64 #5f8700  133 153   0 
//---------------------

